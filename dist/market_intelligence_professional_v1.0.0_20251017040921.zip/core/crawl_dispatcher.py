import queue
import threading
import time
from typing import List, Dict, Any
from scrapers.amazon_scraper import scrape_amazon
from scrapers.logger import log_info, log_error
from core.storage.db_manager import StorageEngine

class CrawlTask:
    def __init__(self, url: str, params: Dict[str, Any]):
        self.url = url
        self.params = params

class Dispatcher:
    def __init__(self, storage_mode="local", worker_count=2):
        self.task_queue = queue.Queue()
        self.workers: List[threading.Thread] = []
        self.running = False
        self.storage = StorageEngine(mode=storage_mode)
        self.worker_count = worker_count
        self.results_accum: List[Dict[str, Any]] = []

    def add_tasks(self, urls: List[str], base_params: Dict[str, Any]):
        for u in urls:
            self.task_queue.put(CrawlTask(u, base_params))
        log_info(f"[Dispatcher] 已添加 {len(urls)} 个任务。")

    def worker_loop(self, wid: int):
        while self.running:
            try:
                task: CrawlTask = self.task_queue.get(timeout=2)
            except Exception:
                continue
            log_info(f"[Worker-{wid}] 开始处理: {task.url}")
            try:
                items = scrape_amazon(
                    url=task.url,
                    max_items=task.params.get("max_items", 30),
                    resume=False,
                    use_proxy=task.params.get("use_proxy", True),
                    deep_detail=task.params.get("deep_detail", False),
                    storage_mode="local",  # 这里抓完统一由 dispatcher 保存
                    headless=True
                )
                self.results_accum.extend(items)
                log_info(f"[Worker-{wid}] 完成: {task.url} -> {len(items)} 条")
            except Exception as e:
                log_error(f"[Worker-{wid}] 任务失败 {task.url}: {e}")
            finally:
                self.task_queue.task_done()
            time.sleep(1.0)

    def start(self):
        self.running = True
        for i in range(self.worker_count):
            t = threading.Thread(target=self.worker_loop, args=(i,), daemon=True)
            t.start()
            self.workers.append(t)
        log_info(f"[Dispatcher] 已启动 {self.worker_count} 个线程。")

    def wait_finish(self):
        self.task_queue.join()
        self.running = False
        self.storage.save_products("batch_dispatch", self.results_accum)
        self.storage.close()
        log_info(f"[Dispatcher] 全部任务完成，总计 {len(self.results_accum)} 条。")

def run_batch(urls: List[str], storage_mode="local"):
    disp = Dispatcher(storage_mode=storage_mode, worker_count=3)
    params = {"max_items": 20, "use_proxy": True, "deep_detail": False}
    disp.add_tasks(urls, params)
    disp.start()
    disp.wait_finish()