from typing import List, Dict, Any
import streamlit as st
import os
from scrapers import amazon_scraper

API_CONFIGS = {
    "Amazon": {"api_key": None, "endpoint": None},
}

PLATFORM_LIST = ["Amazon"]

@st.cache_data(ttl=1800)
def get_platform_data(
    platform_name: str,
    keyword: str = "",
    category_url: str = "",
    max_items: int = 50,
    deep_detail: bool = True
) -> List[Dict[str, Any]]:
    api_info = API_CONFIGS.get(platform_name)
    if api_info and api_info.get("api_key"):
        st.info(f"{platform_name} API 优先，但尚未实现，切换爬虫。")

    st.info(f"正在通过爬虫获取 {platform_name} 数据 ...")

    if platform_name == "Amazon":
        try:
            if category_url:
                target_url = category_url.strip()
            elif keyword:
                target_url = f"https://www.amazon.com/s?k={keyword.strip()}"
            else:
                target_url = "https://www.amazon.com/bestsellers"

            data = amazon_scraper.scrape_amazon(
                url=target_url,
                max_items=max_items,
                resume=True,
                use_proxy=True,
                deep_detail=deep_detail,
                storage_mode="local",
                headless=True
            )
            st.success(f"成功获取 {len(data)} 条。")
            return data
        except Exception as e:
            st.error(f"采集失败: {e}")
            return []
    st.warning(f"{platform_name} 未实现采集逻辑。")
    return []