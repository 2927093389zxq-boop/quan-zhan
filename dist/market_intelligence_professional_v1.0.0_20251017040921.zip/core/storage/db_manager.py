import os
import json
import time
from typing import List, Dict, Any
from pymongo import MongoClient
import mysql.connector
from .cloud_storage import CloudStorage
from scrapers.logger import log_info, log_error

class StorageEngine:
    def __init__(self, mode: str = "local"):
        self.mode = mode
        self.mongo_client = None
        self.mongo_collection = None
        self.mysql_conn = None
        self.cloud = None
        self._init_backends()

    def _init_backends(self):
        if self.mode == "mongo":
            uri = os.getenv("MONGO_URI")
            db_name = os.getenv("MONGO_DB", "amazon_crawl")
            col_name = os.getenv("MONGO_COLLECTION", "products")
            if not uri:
                log_error("[Storage] 未配置 MONGO_URI，回退 local")
                self.mode = "local"
                return
            self.mongo_client = MongoClient(uri)
            self.mongo_collection = self.mongo_client[db_name][col_name]
            log_info(f"[Storage] MongoDB 已连接: {db_name}/{col_name}")
        elif self.mode == "mysql":
            try:
                self.mysql_conn = mysql.connector.connect(
                    host=os.getenv("MYSQL_HOST", "127.0.0.1"),
                    port=int(os.getenv("MYSQL_PORT", "3306")),
                    user=os.getenv("MYSQL_USER", "root"),
                    password=os.getenv("MYSQL_PASSWORD", ""),
                    database=os.getenv("MYSQL_DB", "amazon_crawl")
                )
                self._ensure_mysql_table()
                log_info("[Storage] MySQL 已连接。")
            except Exception as e:
                log_error(f"[Storage] MySQL 连接失败: {e} 回退 local")
                self.mode = "local"
        elif self.mode == "cloud":
            self.cloud = CloudStorage()
            log_info("[Storage] 云存储模式初始化完成。")
        else:
            log_info("[Storage] 使用 local (JSON) 模式。")

    def _ensure_mysql_table(self):
        cursor = self.mysql_conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(512),
            url VARCHAR(512),
            price VARCHAR(64),
            desc TEXT,
            ts BIGINT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        self.mysql_conn.commit()

    def save_products(self, key: str, products: List[Dict[str, Any]]):
        ts = int(time.time())
        if self.mode == "local":
            fname = f"data/{key.replace('/', '_')}_{ts}.json"
            os.makedirs("data", exist_ok=True)
            with open(fname, "w", encoding="utf-8") as f:
                json.dump(products, f, ensure_ascii=False, indent=2)
            log_info(f"[Storage] Local 保存成功: {fname}")
        elif self.mode == "mongo":
            for p in products:
                p["_source_key"] = key
                p["_ts"] = ts
            if products:
                self.mongo_collection.insert_many(products)
            log_info(f"[Storage] MongoDB 已插入 {len(products)} 条。")
        elif self.mode == "mysql":
            cursor = self.mysql_conn.cursor()
            for p in products:
                cursor.execute(
                    "INSERT INTO products (title,url,price,desc,ts) VALUES (%s,%s,%s,%s,%s)",
                    (p.get("title",""), p.get("url",""), p.get("price",""), p.get("desc",""), ts)
                )
            self.mysql_conn.commit()
            log_info(f"[Storage] MySQL 已插入 {len(products)} 条。")
        elif self.mode == "cloud":
            self.cloud.save_json(key, products)
        else:
            log_error(f"[Storage] 未知模式: {self.mode}")

    def close(self):
        if self.mongo_client:
            self.mongo_client.close()
        if self.mysql_conn:
            self.mysql_conn.close()